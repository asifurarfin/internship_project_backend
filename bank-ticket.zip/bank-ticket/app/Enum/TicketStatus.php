<?php

namespace App\Enum;

enum TicketStatus : string
{
    case IN_PROGRESS = 'in_progress';
    case APPROVE = 'approve';
    case SOLVE ='solve';
    case REJECT ='reject';
}
